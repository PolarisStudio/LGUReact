var a = 10, b = 20, c = 30;

//max of three
if (a>=b && a>=c){
    max = a;
}
else if(b>=a && b>=c){
    max = b;
}
else{
    max = c;
}

console.log("Max is", max)

//while sentence
var t = 0;
while (t<=100){
    console.log(t);
    t += 1;
}

//for sentence
for (var i=1;i<=100;i+=1){
    
}